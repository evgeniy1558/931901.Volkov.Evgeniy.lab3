﻿using Lab3.Parts;

namespace Lab3.Models
{
    public class QuizAnswerModel
    {
        [LessThanOrNull(101, ErrorMessage = "Отсутствует число")]
        public int? Answer { get; set; }
    }
}
